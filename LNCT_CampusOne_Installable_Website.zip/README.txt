LNCT CampusOne — Clickable Frontend Prototype

WHAT THIS IS
- Mobile-friendly clickable frontend prototype for presenting the idea to college staff.
- Student demo login: student@campusone.demo / student123
- College admin demo login: admin@campusone.demo / admin123
- Faculty preview login: faculty@campusone.demo / faculty123
- The sample timetable, faculty, notices and attendance are fictional sample data.
- Demo changes are saved only in the current browser using localStorage. They do NOT sync to other phones and are NOT secure production accounts.
- Faculty login is a preview; real server-enforced faculty-to-subject permissions are NOT implemented yet.
- Do not enter real student data or passwords in this prototype.

OPEN LOCALLY
1. Extract this ZIP on your Android phone.
2. Open index.html in a browser if your file manager supports it, or upload index.html to the root of the existing GitHub Pages repository.
3. For GitHub Pages, replace the old index.html with this one and commit changes. Keep filenames lowercase and at repository root.

REAL ONLINE BACKEND ROADMAP (recommended beginner route: Firebase)
Phase 1 — College approval and requirements
- Get written approval to use LNCT name/logo and to pilot the app.
- Confirm who owns student data, which staff can edit which sections, retention/backup rules, and who handles support.
- Start with one CSE section and sample data until approval.

Phase 2 — Create Firebase project (free Spark plan where eligible)
1. On Android Chrome, open https://console.firebase.google.com/ and sign in with a Google account.
2. Create a project named LNCT-CampusOne-Pilot (or another available name). Do not enable billing unless the college approves it.
3. Add a Web App in Project settings and copy its Firebase config.
4. Enable Authentication > Sign-in method > Email/Password.
5. Create Cloud Firestore database. Choose a region appropriate to the institution and confirm data-location requirements with college IT first.
6. Do not put admin passwords or service-account keys inside frontend files.

Phase 3 — Data model to build
- users: uid, name, collegeEmail, studentId/staffId, role, branch, semester, section, active
- subjects: subjectId, name, code, branch, semester, facultyUid(s)
- timetable: sectionId, day, startTime, endTime, subjectId, room, type (lecture/lab/workshop), status
- attendance: studentUid, subjectId, date, status, markedByUid, updatedAt
- notices: title, body, audience, createdByUid, publishedAt, expiresAt
- events: title, type, date, time, venue, audience
- facultyAvailability: facultyUid, status, updatedAt, updatedByUid
- requests: studentUid, category, message, status, response, assignedToUid, createdAt

Phase 4 — Security before real use
- Use Firebase Authentication, never a client-side hardcoded password list.
- Add server-enforced Firestore Security Rules: students can read only their own profile/attendance and relevant section data; faculty can write attendance only for assigned classes; admin permissions must be granted explicitly by trusted college IT.
- Never trust a role value supplied by the browser alone. Validate permissions in Firestore rules or trusted backend code.
- Test with separate student, faculty and admin accounts, including attempts to access another student's records.
- Use least-privilege access, backups, audit logs where feasible, and an incident/contact process.

Phase 5 — Pilot
- Import only approved, minimum necessary data; test timetable changes, attendance corrections, notice targeting, time zones, mobile connectivity and backups.
- Have faculty/admin verify data before students rely on it. Faculty availability is not live unless connected to an approved real source.
- Collect feedback from one section; fix issues; expand only after college sign-off.

COST AND LIMITATIONS
- Firebase has a no-cost Spark plan for eligible services, subject to quotas and product limitations. Verify current pricing/limits before launch: https://firebase.google.com/pricing
- A free plan does not guarantee every feature is free at any scale. Push notifications, custom domain, integrations, file storage and usage may have limits or extra requirements.
- GitHub Pages hosts static frontend files only; it does not provide secure login, shared database, authorization or private storage by itself.
- This ZIP is a frontend prototype plus implementation roadmap, NOT a completed production college system. The Firebase project, configuration, data import, security rules and tests still need to be done.


INSTALLABLE WEBSITE UPDATE
This package adds a web app manifest, service worker, app icons, and an Install App button. It must be hosted over HTTPS (GitHub Pages is suitable). Upload ALL files and folders from this ZIP into the repository root, replacing the old index.html and adding manifest.webmanifest, sw.js, and icons/. Then wait for GitHub Pages to publish. Open the published HTTPS site in Chrome and choose Install App, or Chrome menu > Add to Home screen.

DEMO ONLY / SAFETY
This remains a front-end demonstration. Demo logins and changes stored in browser storage are not secure or shared across devices. Do not use real student information or passwords.
